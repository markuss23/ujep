# megatherion
Simple implementation of dataframes for educational purposes (introductory Python course)
